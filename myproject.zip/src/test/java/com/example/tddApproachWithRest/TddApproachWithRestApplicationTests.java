package com.example.tddApproachWithRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TddApproachWithRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
